# AP Comp Sci Clock

A Pen created on CodePen.io. Original URL: [https://codepen.io/goots/pen/bGLgaxW](https://codepen.io/goots/pen/bGLgaxW).

