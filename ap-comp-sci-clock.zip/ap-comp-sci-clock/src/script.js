function showTime() {
  var date = new Date();
  var h = date.getHours(); // 0 - 23
  var m = date.getMinutes(); // 0 - 59
  var s = date.getSeconds(); // 0 - 59
  var session = "Ante Meridiem";
  var ms = date.getMilliseconds();

  if (h == 0) {
    h = 12;
  }

  if (h > 12) {
    h = h - 12;
    session = "Post Meridiem";
  }
  ms = ms < 10 ? "0" + ms : ms;
  h = h < 10 ? "0" + h : h;
  m = m < 10 ? "0" + m : m;
  s = s < 10 ? "0" + s : s;

  if (ms)
    var time =
      "The current time is: " +
      h +
      ":" +
      m +
      ":" +
      s +
      ":" +
      ms +
      " " +
      "\n" +
      session;
  document.getElementById("display").innerText = time;

  setTimeout(showTime, 1);
}

showTime();

function updateClock() {
  var date = new Date();
  var mo = date.getMonth();
  var yr = date.getFullYear();
  var dy = date.getDate();
  var months = [
    "January",
    "February",
    "March",
    "April",
    "May",
    "June",
    "July",
    "August",
    "September",
    "October",
    "November",
    "December"
  ];
  var tags = ["mon", "d", "y"],
    corr = [months[mo], dy, yr];
  for (var i = 0; i < tags.length; i++)
    document.getElementById(tags[i]).firstChild.nodeValue = corr[i];
}
function initClock() {
  updateClock();
  window.setInterval("updateClock()", 1);
}

function showTime() {
  var date = new Date();
  var h = date.getHours(); // 0 - 23
  var m = date.getMinutes(); // 0 - 59
  var s = date.getSeconds(); // 0 - 59
  var session = "Ante Meridiem (AM)";
  var ms = date.getMilliseconds();

  if (h == 0) {
    h = 12;
  }

  if (h > 12) {
    h = h - 12;
    session = "Post Meridiem (PM)";
  }
  ms = ms < 10 ? "0" + ms : ms;
  h = h < 10 ? "0" + h : h;
  m = m < 10 ? "0" + m : m;
  s = s < 10 ? "0" + s : s;

  if (ms)
    var time =
      "The current time is: " +
      h +
      ":" +
      m +
      ":" +
      s +
      ":" +
      ms +
      " " +
      "\n" +
      session;
  document.getElementById("display").innerText = time;

  setTimeout(showTime, 1);
}
